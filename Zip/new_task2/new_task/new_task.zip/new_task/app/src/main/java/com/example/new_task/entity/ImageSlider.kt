package com.example.new_task.entity

import android.net.Uri

data class ImageSlider(
     var id:Int,
     var img:String
 )