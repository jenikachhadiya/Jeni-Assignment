package com.example.new_task.entity

data class Category(
    var id:Int,
    var Img:String
)
