package com.gautam.validatonformgrewon.modal

import androidx.room.Entity
import androidx.room.PrimaryKey


@Entity(tableName = "user_table")
data class Users(
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0,
    var name: String,
    var image: String?,
    var email: String,
    var passworld: String,
    var conformpassworld: String,
    var gender:String

    )
