package com.gautam.validatonformgrewon.modal

import com.gautam.validatonformgrewon.base64.BaseImage

data class Listview(

    var id:Int,
    var image:String,
    var ratting:Double,
    var description:String,
    var title:String

)
