package com.gautam.validatonformgrewon.fragments

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.gautam.validatonformgrewon.R
import com.gautam.validatonformgrewon.adapter.AutoAdepter
import com.gautam.validatonformgrewon.adapter.ItemAdapter
import com.gautam.validatonformgrewon.adapter.ListViewAdepter
import com.gautam.validatonformgrewon.adapter.ShoppingAdepter
import com.gautam.validatonformgrewon.databinding.FragmentHomeBinding
import com.gautam.validatonformgrewon.modal.AutoViewPage
import com.gautam.validatonformgrewon.utilslist.UtilList.Companion.getAlliteamList
import com.gautam.validatonformgrewon.utilslist.UtilList.Companion.getItemList
import com.gautam.validatonformgrewon.utilslist.UtilList.Companion.getshoppingList
import java.util.*


class HomeFragment : Fragment() {

    lateinit var binding: FragmentHomeBinding
    var iteamlist = mutableListOf<AutoViewPage>()
    lateinit var autoadepter: AutoAdepter
    lateinit var itemadepter: ItemAdapter
    lateinit var shoping: ShoppingAdepter
    lateinit var listview:ListViewAdepter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        Autoslieder()

        itemadepter = ItemAdapter(requireContext(), getItemList(requireContext()))
        binding.rcvItem.layoutManager =
            LinearLayoutManager(requireContext(), LinearLayoutManager.HORIZONTAL, false)
        binding.rcvItem.adapter = itemadepter

        shoping = ShoppingAdepter(requireContext(), getshoppingList(requireContext()))
        binding.revShop.layoutManager = LinearLayoutManager(
            requireContext(), LinearLayoutManager.HORIZONTAL, false
        )
        binding.revShop.adapter = shoping

         listview= ListViewAdepter(requireContext(), getAlliteamList(requireContext()))
        binding.revList.layoutManager=LinearLayoutManager(requireContext(),LinearLayoutManager.VERTICAL,false)
        binding.revList.adapter=listview
    }

    private fun Autoslieder() {
        iteamlist.add(AutoViewPage(1, getString(R.string.veg_auto)))
        iteamlist.add(AutoViewPage(2, getString(R.string.burger_auto)))
        iteamlist.add(AutoViewPage(3, getString(R.string.pizza_auto)))
        iteamlist.add(AutoViewPage(4, getString(R.string.best_vegitables)))
        autoadepter = AutoAdepter(requireContext(), imagelist = iteamlist)
        binding.ivViewAutoscroll.adapter = autoadepter
        binding.dotsIndicator.attachTo(binding.ivViewAutoscroll)

        val handler = Handler(Looper.getMainLooper())
        val update = Runnable {
            if (binding.ivViewAutoscroll.currentItem == autoadepter.count - 1) {
                binding.ivViewAutoscroll.currentItem = 0
            } else {
                binding.ivViewAutoscroll.currentItem++
            }
        }

        Timer().schedule(object : TimerTask() {
            override fun run() {
                handler.post(update)
            }
        }, 1000, 2000)


    }


}