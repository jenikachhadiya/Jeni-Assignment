package com.gautam.validatonformgrewon.modal

import com.gautam.validatonformgrewon.base64.BaseImage
import java.net.IDN

data class IteamList(

    var id:Int,
    var text:String,
    var image:String

)
