package com.gautam.validatonformgrewon.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.gautam.validatonformgrewon.LoginActivity
import com.gautam.validatonformgrewon.R
import com.gautam.validatonformgrewon.databinding.FragmentSettingsBinding
import com.gautam.validatonformgrewon.shareprefrence.PrefManager


class SettingsFragment : Fragment() {

    lateinit var binding: FragmentSettingsBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {

        binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btLogout.setOnClickListener {
            PrefManager(requireContext()).clear()
            val i = Intent(requireContext(), LoginActivity::class.java)
            startActivity(i)
            requireActivity().finish()
            Toast.makeText(
                requireContext(), getString(R.string.logout_successfully), Toast.LENGTH_SHORT
            ).show()


        }
    }

}