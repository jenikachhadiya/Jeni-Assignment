package com.gautam.validatonformgrewon

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.gautam.validatonformgrewon.databinding.ActivityMainBinding
import com.gautam.validatonformgrewon.fragments.HomeFragment
import com.gautam.validatonformgrewon.fragments.ProfileFragments
import com.gautam.validatonformgrewon.fragments.SettingsFragment

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        replaceFragment(HomeFragment(), "Home")

        binding.bnBottomnavi.setOnItemSelectedListener {
            when (it.itemId) {

                R.id.ic_home -> {
                    replaceFragment(HomeFragment(), "Home")
                    true
                }
                R.id.ic_profile -> {

                    replaceFragment(ProfileFragments(), "profils")
                    true
                }
                R.id.ic_seeting -> {

                    replaceFragment(SettingsFragment(), "settings")
                    true
                }

                else -> {

                    false

                }

            }


        }


    }

    private fun replaceFragment(fragment: Fragment, tag: String) {
        var manager = supportFragmentManager
        val transaction = manager.beginTransaction()
        transaction.replace(R.id.fl_wallpeper, fragment, tag)
        transaction.commit()


    }


}