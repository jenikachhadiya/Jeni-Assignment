package com.gautam.validatonformgrewon.utilslist

import android.content.Context
import com.gautam.validatonformgrewon.R
import com.gautam.validatonformgrewon.modal.IteamList
import com.gautam.validatonformgrewon.modal.Listview
import com.gautam.validatonformgrewon.modal.Shopping

class UtilList {

    companion object {


        fun getItemList(context: Context): ArrayList<IteamList> {
            val maniyitemlist = ArrayList<IteamList>()
            maniyitemlist.add(
                IteamList(
                    1, context.getString(R.string.sports), context.getString(R.string.sportimage)
                )
            )
            maniyitemlist.add(
                IteamList(
                    2, context.getString(R.string.Bikes), context.getString(R.string.bikesimage)
                )
            )
            maniyitemlist.add(
                IteamList(
                    3, context.getString(R.string.mobiles), context.getString(R.string.mobileimage)
                )
            )
            maniyitemlist.add(
                IteamList(
                    4, context.getString(R.string.shirt), context.getString(R.string.sharetsimage)
                )
            )
            maniyitemlist.add(
                IteamList(
                    5,
                    context.getString(R.string.t_shirt),
                    context.getString(R.string.t_shiretimage)
                )
            )
            maniyitemlist.add(
                IteamList(
                    6, context.getString(R.string.laptop), context.getString(R.string.laptopsimage)
                )
            )
            maniyitemlist.add(
                IteamList(
                    7,
                    context.getString(R.string.jewellery),
                    context.getString(R.string.jewllriimage)
                )
            )
            return maniyitemlist
        }

        fun getshoppingList(context: Context): ArrayList<Shopping> {
            var shopping = java.util.ArrayList<Shopping>()


            shopping.add(
                Shopping(
                    2,
                    context.getString(R.string.lunchboximage),
                    context.getString(R.string.lunch_Box),
                    4.5
                )
            )
            shopping.add(
                Shopping(
                    3,
                    context.getString(R.string.lightimage),
                    context.getString(R.string.LightLamp),
                    4.0
                )
            )
            shopping.add(
                Shopping(
                    4,

                    context.getString(R.string.Facialimage),
                    context.getString(R.string.Facial_wash),
                    3.5
                )
            )
            shopping.add(
                Shopping(
                    5,
                    context.getString(R.string.Acimage),
                    context.getString(R.string.AC),
                    5.0
                )
            )
            shopping.add(
                Shopping(
                    1,
                    context.getString(R.string.bottleimage),
                    context.getString(R.string.bottle),
                    2.5

                )
            )

            return shopping
        }

        fun getAlliteamList(context: Context): ArrayList<Listview> {
            var list = ArrayList<Listview>()

            list.add(
                Listview(
                    1,
                    context.getString(R.string.helthyharimage),
                    3.5,
                    "Prevents dandruff, itchy scalp, and keeps hair healthy by improving circulation.",
                    context.getString(R.string.healthy_hair)
                )
            )
            list.add(
                Listview(
                    2,
                    context.getString(R.string.Zanduimage),
                    4.5,
                    "Zandu Kesari Jivan gives you power & helps build endurance while keeping you energetic, throughout the day.",
                    context.getString(R.string.Zandu)
                )
            )
            list.add(
                Listview(
                    3,
                    context.getString(R.string.homepreimium_image),
                    4.0,
                    "Each Lama is unisex & size-inclusive which means we are one size fits all",
                    context.getString(R.string.Home_premium_store)
                )
            )
            list.add(
                Listview(
                    4,
                    context.getString(R.string.Symactive_image),
                    5.0,
                    "Warranty: This product comes with a 6 months warranty.",
                    context.getString(R.string.Symactive)
                )
            )
            list.add(
                Listview(
                    5,
                    context.getString(R.string.Manjauar_image),
                    4.5,
                    "Kurta Material :- Cotton Blend, Bottom Material: Cotton",
                    context.getString(R.string.Manjauar)
                )
            )
            return list
        }

    }


}