package com.gautam.validatonformgrewon.modal

data class Shopping(

    var id:Int,
    var image:String,
    var text:String,
    var ratting:Double

)
