package com.gautam.validatonformgrewon.shareprefrence

class Constant {


    companion object{

        const val USER = "user-info"
        const val PREF_NAME = "my-pref"
        const val EMAIL = "email"
        const val PASS = "password"



    }

}