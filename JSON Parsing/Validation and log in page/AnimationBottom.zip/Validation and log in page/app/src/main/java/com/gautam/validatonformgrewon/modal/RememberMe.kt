package com.gautam.validatonformgrewon.modal


data class RememberMe(
    var email: String, var passworld: String, var isRemember: Boolean = false
)
