package com.gautam.validatonformgrewon.modal

class AutoViewPage (

    var id:Int,
    var image:String


        )