package com.gautam.validatonformgrewon.dao

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.gautam.validatonformgrewon.modal.Users

@Dao
interface UserDao {

    @Insert
    fun insertRecord(user: Users)

    @Query("select * from `user_table`")
    fun getUserList(): LiveData<List<Users>>

    @Query("select * from `user_table` where id = :uid")
    fun getUser(uid: Int): Users

    @Query("select * from `user_table` where email =:email ")
    fun getEmail(email: String): Users?

    @Update
    fun updateRecord(user: Users)

   /* @Query(" UPDATE User SET pass:password WHERE email=:email")
    fun updatedata(Email:String?,pass:String?):Int
*/
    @Query("UPDATE USER_TABLE SET passworld = :pass WHERE email=:Email ")
    fun updaredata(Email: String?,pass:String)


}