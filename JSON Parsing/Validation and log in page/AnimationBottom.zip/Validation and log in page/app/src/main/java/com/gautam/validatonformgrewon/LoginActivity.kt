package com.gautam.validatonformgrewon

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.gautam.validatonformgrewon.databinding.ActivityLoginBinding
import com.gautam.validatonformgrewon.entiy.AppDataBase
import com.gautam.validatonformgrewon.modal.RememberMe
import com.gautam.validatonformgrewon.modal.Users
import com.gautam.validatonformgrewon.shareprefrence.PrefManager
import com.gautam.validatonformgrewon.utils.Utils

class LoginActivity : AppCompatActivity() {

    lateinit var binding: ActivityLoginBinding
    lateinit var db: AppDataBase
    lateinit var prefManager: PrefManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prefManager = PrefManager(this)

        if (prefManager.getRememberMe() != null) {
            binding.remember.isChecked = prefManager.getRememberMe()!!.isRemember
            if (prefManager.getRememberMe()!!.isRemember) {
                binding.logEmail.setText(prefManager.getRememberMe()?.email)
                binding.logLconpassworld.setText(prefManager.getRememberMe()?.passworld)
            }
        }

        binding.tvForgetpassword.setOnClickListener {
            val i = Intent(this, ForgotpassActivity::class.java)
            startActivity(i)
            finish()
        }

        db = AppDataBase.getInstance(this)



        binding.tvYounotaccount.setOnClickListener {
            val i = Intent(this, SignupActivity::class.java)
            startActivity(i)
        }



        binding.btLogin.setOnClickListener {
            val email = binding.logEmail.text.toString().trim()
            val password = binding.logLconpassworld.text.toString().trim()

            if (email.isEmpty()) {
                binding.logEmail.error = getString(R.string.Enter_email)
                binding.logEmail.requestFocus()
            } else if (!Utils.isValidEmail(email)) {
                binding.logEmail.error = getString(R.string.Enter_valid_format_email)
                binding.logEmail.requestFocus()
            } else if (password.isEmpty()) {
                binding.logLconpassworld.error = getString(R.string.enter_register_password)
                binding.logLconpassworld.requestFocus()
            } else if (!Utils.isValidpassword(password)) {
                binding.logLconpassworld.error =
                    getString(R.string.Upper_case_with_lover_case_character)
                binding.logLconpassworld.requestFocus()
            } else {

                doLogin(
                    binding.logEmail.text.toString().trim(),
                    binding.logLconpassworld.text.toString().trim()
                )


            }

        }

    }


    private fun doLogin(email: String, pass: String) {
        db.userDao().getUserList().observe(this) {
            var userData: Users? = null
            for (data in it) {
                if (data.email == email) {
                    userData = data
                }
            }
            if (userData != null) {
                if (userData.passworld == pass) {
                    prefManager.saveLoginCredentials(userData)
                    rememberMe()
                    startActivity(Intent(this, MainActivity::class.java))
                    finishAffinity()
                } else {
                    Toast.makeText(
                        applicationContext,
                        getString(R.string.password_is_wrong),
                        Toast.LENGTH_SHORT
                    ).show()
                }
            } else {
                Toast.makeText(
                    applicationContext,
                    getString(R.string.your_email_address_is_not_exist),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    private fun rememberMe() {
        val rememberMe = RememberMe(
            binding.logEmail.text.toString(),
            binding.logLconpassworld.text.toString(),
            binding.remember.isChecked
        )
        prefManager.saveRememberMe(rememberMe)
    }


}


